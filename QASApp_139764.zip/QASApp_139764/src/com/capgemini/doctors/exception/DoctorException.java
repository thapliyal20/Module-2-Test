package com.capgemini.doctors.exception;

public class DoctorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1001L;

	public DoctorException(String message) {
		super(message);
	}
	

}
